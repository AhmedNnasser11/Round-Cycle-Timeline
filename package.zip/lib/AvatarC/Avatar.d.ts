import React from "react";
declare const Avatar: ({ item }: {
    item: any;
}) => React.JSX.Element;
export default Avatar;
