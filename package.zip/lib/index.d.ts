import './App.css';
import React from "react";
interface CyrcleTimeLineProps<T> {
    innerCyrcleClasss?: string;
    avatarComponent?: React.ComponentType<{
        item: T;
    }>;
    avatarContainerClasss?: string;
    arrayData?: T[] | any[];
    rotate?: boolean;
    duration?: number;
    relativeContainerClasss?: string;
}
export default function CyrcleTimeLine<T>({ innerCyrcleClasss, avatarComponent, avatarContainerClasss, arrayData, rotate, duration, relativeContainerClasss, }: CyrcleTimeLineProps<T>): React.JSX.Element;
export {};
